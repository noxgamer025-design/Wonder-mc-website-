-- Run this in the Supabase SQL Editor (Dashboard → SQL Editor → New query)

create table if not exists public.store_state (
  id text primary key,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz default now()
);

-- Keep RLS enabled. The Express backend uses the service-role key server-side.
-- Do not add anon/public read or write policies for this private global state table.
alter table public.store_state enable row level security;

-- Optional: allow public read of non-sensitive data later if you move to structured tables
-- For now the backend uses the service role key, so no extra policies are required.

-- Insert the initial empty row (the app will fill it on first save)
insert into public.store_state (id, data)
values ('global', '{}'::jsonb)
on conflict (id) do nothing;
