# WonderMC — Full-stack deployment package

WonderMC is a React/Vite storefront with an Express API and Supabase-backed persistence. Deploy the **whole repository** to a Node.js web service (for example Render). A static-only Vercel/Vite deployment does not run `server.ts` or its `/api/*` routes; use a Node service for the backend unless you separately port every API route to Vercel Functions.

## Included

- Existing WonderMC storefront, store pages, admin interface and support/payment workflows.
- Express API for admin authentication, ticket submissions and persistent state.
- Supabase `store_state` persistence; the service-role key is used only on the server.
- Protected admin ticket retrieval and permission checks.
- Discord notifications containing only ticket number, gamertag and category. Payment UTRs, screenshots, contacts and support message contents are not sent to Discord.

## Required environment variables

Set these as private environment variables in your hosting dashboard. Never use `VITE_` prefixes for secrets and never commit a real `.env` file.

- `SUPABASE_URL` — your Supabase project URL.
- `SUPABASE_SERVICE_ROLE_KEY` — a **newly rotated** service-role key. Keep it server-side only.
- `OWNER_PASSWORD` — a new, unique random password of at least 16 characters.
- `NODE_ENV=production`.
- `GEMINI_API_KEY` — optional, only if a feature you use requires it.

The Supabase table is `public.store_state`. Run `supabase-setup.sql` in the Supabase SQL Editor. Keep Row Level Security enabled and do not add public read/write policies for this table; the server uses the service-role key.

## Important credential rotation

The original project archive contained a real-looking Supabase service-role key, an owner password, and sample sub-admin passwords. Treat all of them as compromised. Before deployment:

1. Rotate the Supabase service-role key in Supabase and update `SUPABASE_SERVICE_ROLE_KEY` in the hosting dashboard.
2. Set a new `OWNER_PASSWORD` in the hosting dashboard. The old browser-embedded owner password has been removed; authentication now uses server-issued session tokens.
3. Remove/recreate any other sub-admin passwords that were previously shared or used in the old project. The known sample keys are automatically invalidated by the server migration.
4. If the old values were committed to a public GitHub repository, remove them from Git history as well as the latest files. Rotating credentials is still required even after history cleanup.
5. Review the old payment record in Supabase. The packaged local snapshot has been scrubbed, but this does not delete records already stored in your live Supabase database.

## Deploy on Render

1. Push the project folder to your GitHub repository. Check that no real `.env`, service-role key, webhook URL or payment screenshot is included.
2. Create a Render **Web Service** connected to that repository.
3. Runtime: Node. Build command: `npm install && npm run build`. Start command: `npm start`. Health check: `/api/health`.
4. Add the environment variables above and deploy.
5. Open `/api/health`, then test admin login, a support ticket and a payment submission using a test record. Confirm the private UTR/screenshot appear only in the Admin Panel, while Discord receives only a minimal alert.

## Discord webhook

Configure the webhook from the Admin Panel settings. The full URL is stored server-side and is not returned by public APIs or written to browser localStorage. After reload, the UI shows whether a webhook is configured; paste a new URL only when you want to replace it. The test button uses the authenticated server endpoint.

## Local development

Requirements: Node.js 20+ and npm.

```sh
npm install
cp .env.example .env
# Fill in private Supabase credentials and a new OWNER_PASSWORD in .env
npm run dev
```

## Security behaviour

- Public `/api/state` omits tickets, activity logs, sub-admin keys and private coupons; the Discord webhook URL is never returned.
- `/api/admin/tickets` requires an authenticated session with the `tickets` permission. Admin sessions are opaque, server-issued tokens and expire after eight hours.
- Ticket submissions are stored server-side. The browser no longer saves UTRs or payment screenshots in localStorage. Legacy local ticket storage is cleared.
- Payment proof and support messages are visible only to authorised ticket staff through the Admin Panel. Discord alerts contain only ticket number, gamertag and category.
- Payments remain **manual verification only**. A submission is not proof of payment and does not automatically grant in-game items.
- Public ticket submissions have basic in-memory rate limiting. Add a managed WAF/CAPTCHA and persistent rate limiting before a high-traffic launch.
- Local `store_backend.json` is a fallback snapshot, not a substitute for Supabase. Do not commit live payment records into it.

## DPDP / children: remaining operator action

The code now adds a privacy notice and acknowledgement, minimises Discord sharing, and restricts access to payment/support records. This alone does **not** establish full DPDP Act compliance. The operator must confirm the applicable commencement dates and obligations, set an appropriate retention schedule, publish a monitored privacy contact, and implement a verifiable parental-consent process before processing personal data of users under 18. A checkbox or a gamertag is not verifiable parental consent. Until that process exists, do not accept personal data from under-18 users. Obtain an India-qualified legal review before making a compliance claim.

## Build verification

Run `npm install && npm run build` in the deployment environment before going live. Dependency installation could not complete in the editing environment, so a full production build has not been verified here.
