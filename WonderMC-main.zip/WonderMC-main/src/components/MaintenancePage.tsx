import React, { useEffect, useState } from 'react';
import { Clock3, Wrench, ShieldCheck } from 'lucide-react';

const MAINTENANCE_END_AT = new Date(
  '2026-11-10T09:09:00Z'
).getTime();

function getRemainingTime() {
  const difference = Math.max(0, MAINTENANCE_END_AT - Date.now());

  return {
    hours: Math.floor(difference / 3600000),
    minutes: Math.floor((difference % 3600000) / 60000),
    seconds: Math.floor((difference % 60000) / 1000),
    expired: difference <= 0,
  };
}

export function MaintenancePage() {
  const [time, setTime] = useState(getRemainingTime());

  useEffect(() => {
    const timer = window.setInterval(() => {
      setTime(getRemainingTime());
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  return (
    <main className="wm-maintenance">
      <style>{`
        .wm-maintenance {
          min-height: 100vh;
          min-height: 100dvh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 28px 18px;
          overflow: hidden;
          position: relative;
          background:
            radial-gradient(ellipse at 50% 5%, rgba(139,61,255,.22), transparent 50%),
            radial-gradient(ellipse at 90% 90%, rgba(255,122,26,.10), transparent 45%),
            #08020f;
          color: #f4ead8;
          font-family: 'Outfit', Inter, system-ui, sans-serif;
          text-align: center;
        }

        .wm-maintenance * { box-sizing: border-box; }

        .wm-glow {
          position: absolute;
          width: 300px;
          height: 300px;
          border-radius: 50%;
          background: rgba(139,61,255,.12);
          filter: blur(100px);
          pointer-events: none;
        }

        .wm-maintenance-content {
          position: relative;
          z-index: 1;
          width: 100%;
          max-width: 650px;
          animation: wm-enter .8s ease both;
        }

        @keyframes wm-enter {
          from { opacity: 0; transform: translateY(22px); }
          to { opacity: 1; transform: translateY(0); }
        }

        .wm-logo {
          width: min(220px, 65vw);
          height: auto;
          object-fit: contain;
          margin: 0 auto 25px;
          filter: drop-shadow(0 0 22px rgba(139,61,255,.35));
        }

        .wm-status {
          display: inline-flex;
          align-items: center;
          gap: 9px;
          padding: 9px 16px;
          border: 1px solid rgba(255,122,26,.35);
          border-radius: 999px;
          background: rgba(255,122,26,.08);
          color: #ffb16c;
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 2px;
          text-transform: uppercase;
        }

        .wm-status-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #ff7a1a;
          box-shadow: 0 0 12px #ff7a1a;
          animation: wm-pulse 1.5s infinite;
        }

        @keyframes wm-pulse {
          50% { opacity: .35; }
        }

        .wm-title {
          margin: 27px 0 15px;
          font-size: clamp(36px, 8vw, 64px);
          line-height: 1.08;
          font-weight: 900;
          letter-spacing: -2px;
          background: linear-gradient(110deg, #fff, #ffd29a 50%, #c79bff);
          -webkit-background-clip: text;
          background-clip: text;
          color: transparent;
        }

        .wm-description {
          max-width: 480px;
          margin: 0 auto;
          color: #b8a9c9;
          font-size: 15px;
          line-height: 1.8;
        }

        .wm-countdown {
          margin: 35px auto 25px;
          padding: 23px 15px;
          max-width: 440px;
          border: 1px solid rgba(139,61,255,.35);
          border-radius: 20px;
          background: linear-gradient(145deg, rgba(44,17,80,.65), rgba(18,5,31,.8));
          box-shadow: 0 15px 55px rgba(0,0,0,.25);
        }

        .wm-countdown-label {
          color: #c79bff;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 3px;
          margin-bottom: 18px;
        }

        .wm-time-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
        }

        .wm-time-number {
          display: block;
          color: #fff;
          font-size: clamp(30px, 7vw, 43px);
          font-weight: 800;
          font-variant-numeric: tabular-nums;
        }

        .wm-time-unit {
          display: block;
          margin-top: 5px;
          color: #a995bf;
          font-size: 10px;
          letter-spacing: 2px;
          text-transform: uppercase;
        }

        .wm-info {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          gap: 12px;
          margin: 25px auto;
        }

        .wm-info-item {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 11px 14px;
          border: 1px solid rgba(255,255,255,.09);
          border-radius: 12px;
          background: rgba(255,255,255,.035);
          color: #c8bdd5;
          font-size: 11px;
        }

        .wm-info-item svg {
          color: #ff9a3c;
          width: 15px;
          height: 15px;
        }

        .wm-footer {
          margin-top: 40px;
          color: #766781;
          font-size: 11px;
          letter-spacing: 2px;
        }

        @media (max-width: 380px) {
          .wm-info { flex-direction: column; align-items: center; }
        }
      `}</style>

      <div className="wm-glow" />

      <section className="wm-maintenance-content">
        <img
          className="wm-logo"
          src="/wondermc-logo-glow.png"
          alt="WonderMC"
        />

        <div className="wm-status">
          <span className="wm-status-dot" />
          Scheduled Maintenance
        </div>

        <h1 className="wm-title">
          Something Awesome<br />Is Loading.
        </h1>

        <p className="wm-description">
          We're upgrading the WonderMC experience.
          Our website is temporarily under maintenance
          while we work on making things even better.
          Your patience means a lot to us.
        </p>

        <div className="wm-countdown">
          <div className="wm-countdown-label">
            ESTIMATED RETURN IN
          </div>

          <div className="wm-time-grid">
            <div>
              <span className="wm-time-number">
                {String(time.hours).padStart(2, '0')}
              </span>
              <span className="wm-time-unit">Hours</span>
            </div>

            <div>
              <span className="wm-time-number">
                {String(time.minutes).padStart(2, '0')}
              </span>
              <span className="wm-time-unit">Minutes</span>
            </div>

            <div>
              <span className="wm-time-number">
                {String(time.seconds).padStart(2, '0')}
              </span>
              <span className="wm-time-unit">Seconds</span>
            </div>
          </div>
        </div>

        <div className="wm-info">
          <div className="wm-info-item">
            <Wrench />
            Website upgrades
          </div>

          <div className="wm-info-item">
            <ShieldCheck />
            Your data stays safe
          </div>

          <div className="wm-info-item">
            <Clock3 />
            Back November 10
          </div>
        </div>

        <footer className="wm-footer">
          WONDERMC · SEE YOU SOON
        </footer>
      </section>
    </main>
  );
}
