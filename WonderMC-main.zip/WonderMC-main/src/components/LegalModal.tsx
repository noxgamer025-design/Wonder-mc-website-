import React from 'react';
import { useStoreConfig } from '../context/StoreConfigContext';
import { X, FileText, ShieldAlert, RotateCcw } from 'lucide-react';

export type LegalDocType = 'terms' | 'privacy' | 'refund' | null;

interface LegalModalProps {
  type: LegalDocType;
  onClose: () => void;
}

export const LegalModal: React.FC<LegalModalProps> = ({ type, onClose }) => {
  const { config } = useStoreConfig();
  if (!type) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/75 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl rounded-2xl border border-border bg-surface p-6 shadow-2xl sm:p-7 my-8 max-h-[85vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 rounded-xl border border-border bg-surface-deep p-2 text-muted-foreground hover:text-foreground hover:border-border-strong transition-colors"
          aria-label="Close legal modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Title */}
        <div className="flex items-center gap-3 border-b border-border pb-4 mb-4">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent/15 text-accent">
            {type === 'terms' && <FileText className="w-6 h-6" />}
            {type === 'privacy' && <ShieldAlert className="w-6 h-6" />}
            {type === 'refund' && <RotateCcw className="w-6 h-6" />}
          </div>
          <div>
            <h2 className="text-xl font-black tracking-tight text-foreground font-display">
              {type === 'terms' && 'Terms and Conditions'}
              {type === 'privacy' && 'Privacy Policy'}
              {type === 'refund' && 'Refund Policy'}
            </h2>
            <p className="text-xs text-muted-foreground">
              {config.brand} Network Legal Documentation
            </p>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto pr-2 space-y-4 text-xs text-muted-foreground leading-relaxed">
          {type === 'terms' && (
            <>
              <p>
                By accessing or placing an order on the <strong>{config.brand} Store</strong>, you agree to be bound by these terms. All items sold are virtual in-game privileges and digital goods for the {config.brand} Minecraft Server ({config.serverIp}).
              </p>
              <h4 className="text-sm font-bold text-foreground">1. Minecraft EULA Compliance</h4>
              <p>
                {config.brand} is in no way affiliated with Mojang Studios or Microsoft. All purchases contribute directly to server hosting, custom development, maintenance, and hardware expenses.
              </p>
              <h4 className="text-sm font-bold text-foreground">2. Account Responsibility</h4>
              <p>
                You are responsible for ensuring that the Minecraft username entered at checkout is correct. Staff cannot refund purchases made for the incorrect account name.
              </p>
              <h4 className="text-sm font-bold text-foreground">3. Rule Violations & Ban Policy</h4>
              <p>
                Purchasing ranks or crate keys does not make you immune to server rules. If you are banned or muted for cheating, exploiting, or violating community guidelines, you will not receive a refund or compensation.
              </p>
            </>
          )}

          {type === 'privacy' && (
            <>
              <p>
                {config.brand} processes only information needed to operate the Minecraft store, respond to support requests and manually verify player-submitted payments. This notice explains what is collected, why it is used and how to contact the team about your information.
              </p>
              <h4 className="text-sm font-bold text-foreground">1. Information we collect</h4>
              <p>
                Store payments: Minecraft gamertag, UPI UTR/reference number, payment amount and purchased items, payment screenshot, and optional Discord username/ID. Support requests: gamertag, optional Discord contact, subject, category and the message you submit. We do not ask for your UPI PIN, bank password or full card credentials.
              </p>
              <h4 className="text-sm font-bold text-foreground">2. Why we use it</h4>
              <p>
                We use these details to locate your order, manually compare the UTR and screenshot with the payment received, deliver the purchased in-game items, prevent duplicate or fraudulent claims, and answer support requests. Submitting a payment form does not mean your payment is verified or that an order is automatically fulfilled. An authorised staff member makes that decision.
              </p>
              <h4 className="text-sm font-bold text-foreground">3. Where information is stored and shared</h4>
              <p>
                Submitted payment and support records are stored in the WonderMC server database and are available only through the authenticated Admin Panel to staff authorised to handle tickets/payments. Discord receives a limited alert containing the ticket number, gamertag and category only. UTRs, screenshots, Discord contact details and support message contents are not included in these alerts. Our hosting/database providers process data to operate the service. UPI payment itself is completed in your chosen UPI app/provider.
              </p>
              <h4 className="text-sm font-bold text-foreground">4. Retention and security</h4>
              <p>
                We restrict access to authorised staff and retain records only for as long as needed to verify and fulfil orders, handle support or disputes, and meet applicable legal obligations. Records should then be deleted or irreversibly anonymised. No internet service can guarantee absolute security; please do not send passwords, UPI PINs or unrelated sensitive information in a support message.
              </p>
              <h4 className="text-sm font-bold text-foreground">5. Children and parent/guardian consent</h4>
              <p>
                If you are under 18, ask your parent or legal guardian to contact the WonderMC team before you submit personal information so the team can arrange and verify the required parental consent. A checkbox or a gamertag alone is not parental verification. WonderMC should not process a child’s personal data until the required verifiable parental consent process is in place.
              </p>
              <h4 className="text-sm font-bold text-foreground">6. Your choices and requests</h4>
              <p>
                You or your parent/guardian may request access to, correction of, or deletion of information, or raise a privacy concern, by opening a support ticket or contacting the team through the official Discord server ({config.discordUrl}). We may retain limited records where required by law or needed to resolve a genuine payment dispute. We will verify the request before disclosing or changing account-related information.
              </p>
              <p className="text-[10px] text-muted-foreground">
                This notice is an operational privacy summary, not a legal opinion. The WonderMC operator must confirm the applicable DPDP commencement requirements, establish a verifiable parental-consent process for under-18 users, and publish a monitored privacy contact before claiming full legal compliance.
              </p>
            </>
          )}

          {type === 'refund' && (
            <>
              <p>
                Because all items and ranks delivered on {config.brand} are intangible digital goods consumed immediately in-game, <strong>all sales are final</strong>.
              </p>
              <h4 className="text-sm font-bold text-foreground">1. No Chargebacks</h4>
              <p>
                Attempting an unauthorized chargeback or dispute will result in an immediate and permanent blacklist from the {config.brand} server, our Discord network, and the Tebex/Buycraft community fraud database.
              </p>
              <h4 className="text-sm font-bold text-foreground">2. Missing Items Assistance</h4>
              <p>
                If you made a payment and did not receive your rank or items within 24 hours, please contact us immediately on our Discord server ({config.discordUrl}) with your UTR receipt for manual review and fulfillment.
              </p>
            </>
          )}
        </div>

        <div className="pt-4 border-t border-border mt-4 text-right">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-accent px-5 py-2 text-xs font-black uppercase text-accent-foreground hover:opacity-90"
          >
            I Understand
          </button>
        </div>
      </div>
    </div>
  );
};
