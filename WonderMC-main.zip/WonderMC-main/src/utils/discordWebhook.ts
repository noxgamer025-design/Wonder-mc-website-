import { StoreConfigState } from '../context/StoreConfigContext';

export interface OrderApprovedWebhookData {
  ign: string;
  utr?: string;
  amount: number;
  itemsDescription: string;
  approvedBy?: string;
  ticketNumber?: string;
}

async function postNotification(path: string, payload: Record<string, unknown>, admin = false): Promise<{ success: boolean; error?: string }> {
  try {
    const token = admin ? sessionStorage.getItem('wondermc_admin_auth_token') || '' : '';
    const response = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...(admin ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify(payload),
    });
    const result = await response.json().catch(() => ({}));
    return response.ok ? { success: true } : { success: false, error: result.error || `Notification failed (${response.status})` };
  } catch (error: any) {
    return { success: false, error: error?.message || 'Network error while sending notification' };
  }
}

export async function sendTestDiscordNotification(config: StoreConfigState) {
  return postNotification('/api/admin/discord-test', { webhookUrl: config.discordWebhookUrl || '' }, true);
}

export async function sendOrderApprovedDiscordNotification(data: OrderApprovedWebhookData, _config: StoreConfigState) {
  return postNotification('/api/admin/notify/approved', {
    ign: data.ign,
    ticketNumber: data.ticketNumber,
    approvedBy: data.approvedBy,
  }, true);
}
