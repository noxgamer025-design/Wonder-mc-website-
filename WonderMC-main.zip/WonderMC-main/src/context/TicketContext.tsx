import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { SupportTicket } from '../types';

interface TicketContextType {
  tickets: SupportTicket[];
  addTicket: (data: {
    ign: string;
    contact?: string;
    category: string;
    subject?: string;
    message: string;
    screenshotUrl?: string;
    priority?: SupportTicket['priority'];
  }) => Promise<Pick<SupportTicket, 'id' | 'ticketNumber'>>;
  updateTicketStatus: (id: string, status: SupportTicket['status']) => void;
  updateTicketNote: (id: string, adminNote: string) => void;
  updateTicketPriority: (id: string, priority: SupportTicket['priority']) => void;
  deleteTicket: (id: string) => void;
  clearResolvedTickets: () => void;
  resetTicketsToDefault: () => void;
  openTicketsCount: number;
}

const TicketContext = createContext<TicketContextType | undefined>(undefined);
const ADMIN_TOKEN_KEY = 'wondermc_admin_auth_token';

export const TicketProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  useEffect(() => {
    try { localStorage.removeItem('wondermc_support_tickets_v1'); } catch {}
  }, []);
  const [isLoaded, setIsLoaded] = useState(false);

  const fetchAdminTickets = useCallback(async () => {
    const token = sessionStorage.getItem(ADMIN_TOKEN_KEY) || '';
    if (!token) {
      setTickets([]);
      setIsLoaded(true);
      return;
    }
    try {
      const response = await fetch('/api/admin/tickets?t=' + Date.now(), {
        headers: { Authorization: `Bearer ${token}` },
        cache: 'no-store',
      });
      if (response.status === 401 || response.status === 403) {
        setTickets([]);
        return;
      }
      if (!response.ok) return;
      const data = await response.json();
      if (Array.isArray(data.tickets)) setTickets(data.tickets);
    } catch (error) {
      console.warn('[WonderMC] Could not refresh admin tickets:', error);
    } finally {
      setIsLoaded(true);
    }
  }, []);

  useEffect(() => {
    fetchAdminTickets();
    const interval = window.setInterval(fetchAdminTickets, 15000);
    const handleFocus = () => { if (!document.hidden) fetchAdminTickets(); };
    window.addEventListener('focus', handleFocus);
    window.addEventListener('wondermc-admin-auth', fetchAdminTickets);
    document.addEventListener('visibilitychange', handleFocus);
    return () => {
      window.clearInterval(interval);
      window.removeEventListener('focus', handleFocus);
      window.removeEventListener('wondermc-admin-auth', fetchAdminTickets);
      document.removeEventListener('visibilitychange', handleFocus);
    };
  }, [fetchAdminTickets]);

  useEffect(() => {
    const token = sessionStorage.getItem(ADMIN_TOKEN_KEY) || '';
    if (!isLoaded || !token) return;
    fetch('/api/state', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ tickets }),
    }).catch((error) => console.warn('[WonderMC] Ticket update could not be saved:', error));
  }, [tickets, isLoaded]);

  const addTicket: TicketContextType['addTicket'] = async (data) => {
    const response = await fetch('/api/tickets', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok || !result.ticket) {
      throw new Error(result.error || 'Could not submit your request. Please try again.');
    }
    return result.ticket as Pick<SupportTicket, 'id' | 'ticketNumber'>;
  };

  const updateTicketStatus = (id: string, status: SupportTicket['status']) => setTickets((prev) => prev.map((t) => t.id === id ? { ...t, status } : t));
  const updateTicketNote = (id: string, adminNote: string) => setTickets((prev) => prev.map((t) => t.id === id ? { ...t, adminNote } : t));
  const updateTicketPriority = (id: string, priority: SupportTicket['priority']) => setTickets((prev) => prev.map((t) => t.id === id ? { ...t, priority } : t));
  const deleteTicket = (id: string) => setTickets((prev) => prev.filter((t) => t.id !== id));
  const clearResolvedTickets = () => setTickets((prev) => prev.filter((t) => t.status !== 'resolved' && t.status !== 'closed'));
  const resetTicketsToDefault = () => setTickets([]);
  const openTicketsCount = tickets.filter((t) => t.status === 'open' || t.status === 'in_progress').length;

  return <TicketContext.Provider value={{ tickets, addTicket, updateTicketStatus, updateTicketNote, updateTicketPriority, deleteTicket, clearResolvedTickets, resetTicketsToDefault, openTicketsCount }}>{children}</TicketContext.Provider>;
};

export const useTickets = () => {
  const context = useContext(TicketContext);
  if (!context) throw new Error('useTickets must be used within a TicketProvider');
  return context;
};
