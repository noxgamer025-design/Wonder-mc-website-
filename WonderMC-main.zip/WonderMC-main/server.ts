import express from "express";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";
import { createClient } from "@supabase/supabase-js";

import {
  INITIAL_SUB_ADMIN_KEYS,
  INITIAL_CATEGORIES,
  INITIAL_ITEMS,
  INITIAL_LEADERBOARD,
  INITIAL_STAFF,
  STORE_CONFIG,
  INITIAL_COUPONS,
  INITIAL_ACTIVITY_LOGS,
  INITIAL_UPDATES,
  INITIAL_VOTE_LINKS,
  INITIAL_CONNECTION_GUIDE,
  INITIAL_RULES_CATEGORIES,
} from "./src/data/storeData";

// ============================================================
// App setup
// ============================================================

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.disable("x-powered-by");
app.set("trust proxy", 1);
app.use(express.json({ limit: "16mb" }));

const DATA_FILE = path.join(process.cwd(), "store_backend.json");

// ============================================================
// Supabase setup
// ============================================================

const supabaseUrl = process.env.SUPABASE_URL || "";
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || "";

const supabase = supabaseUrl && supabaseKey
  ? createClient(supabaseUrl, supabaseKey, { auth: { persistSession: false } })
  : null;

const TABLE = "store_state";
const ROW_ID = "global";
const COMPROMISED_SAMPLE_PASSWORD_HASHES = new Set([
  "3770303cb11062ba38e468b24b80a6b710e600ae5ed0f9ae7b8cdcb8c7acde21",
  "cd9406b11fdbba699c8cf2f01aa2a6b4041cbad265b56173cc24a7e30377bff7",
]);
const COMPROMISED_SAMPLE_KEY_IDS = new Set(["key-support-admin", "key-store-manager"]);
function isCompromisedSampleAdminKey(key: any): boolean {
  const password = typeof key?.password === "string" ? key.password : "";
  const passwordHash = crypto.createHash("sha256").update(password).digest("hex");
  return COMPROMISED_SAMPLE_KEY_IDS.has(String(key?.id || "")) || COMPROMISED_SAMPLE_PASSWORD_HASHES.has(passwordHash);
}

// ============================================================
// Default state
// ============================================================

const DEFAULT_STATE: Record<string, any> = {
  subAdminKeys: INITIAL_SUB_ADMIN_KEYS,
  items: INITIAL_ITEMS,
  categories: INITIAL_CATEGORIES,
  leaderboard: INITIAL_LEADERBOARD,
  staffList: INITIAL_STAFF,
  couponsList: INITIAL_COUPONS,
  activityLogs: INITIAL_ACTIVITY_LOGS,
  updatesList: INITIAL_UPDATES,
  voteLinks: INITIAL_VOTE_LINKS,
  tickets: [],
  config: STORE_CONFIG,
  saleConfig: STORE_CONFIG.sale,
  connectionGuide: INITIAL_CONNECTION_GUIDE,
  rulesCategories: INITIAL_RULES_CATEGORIES,
};

// ============================================================
// Local backup + memory cache
// ============================================================

let memoryCache: any = null;
let cacheTime = 0;
const CACHE_TTL_MS = 15_000;

function readLocalBackup(): any {
  try {
    if (!fs.existsSync(DATA_FILE)) return null;
    const raw = fs.readFileSync(DATA_FILE, "utf-8");
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return null;
    return parsed;
  } catch (err) {
    console.error("Local backup read error:", err);
    return null;
  }
}

function writeLocalBackup(data: any): void {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Local backup write error:", err);
  }
}

// ============================================================
// Load state
// ============================================================

async function loadStoreData(forceFresh = false): Promise<any> {
  const now = Date.now();
  if (!forceFresh && memoryCache && now - cacheTime < CACHE_TTL_MS) {
    return memoryCache;
  }

  const localData = readLocalBackup();

  if (supabase) {
    try {
      const { data, error } = await supabase
        .from(TABLE)
        .select("data")
        .eq("id", ROW_ID)
        .maybeSingle();

      if (error) {
        console.error("Supabase load error:", error.message);
      } else if (data?.data) {
        const remoteData = data.data as any;
        if (localData && Number(localData._lastUpdated || 0) > Number(remoteData._lastUpdated || 0)) {
          const merged = { ...DEFAULT_STATE, ...remoteData, ...localData };
          const oldKeys = Array.isArray(merged.subAdminKeys) ? merged.subAdminKeys : [];
          const safeKeys = oldKeys.filter((key: any) => !isCompromisedSampleAdminKey(key));
          merged.subAdminKeys = safeKeys;
          if (safeKeys.length !== oldKeys.length) {
            console.warn("[SECURITY] Removed exposed sample sub-admin passwords from merged state.");
            await saveStoreData(merged);
            return merged;
          }
          memoryCache = merged;
          cacheTime = Date.now();
          return merged;
        }
        const merged = { ...DEFAULT_STATE, ...remoteData };
        const oldKeys = Array.isArray(merged.subAdminKeys) ? merged.subAdminKeys : [];
        const safeKeys = oldKeys.filter((key: any) => !isCompromisedSampleAdminKey(key));
        const compromisedDefaultsFound = safeKeys.length !== oldKeys.length;
        merged.subAdminKeys = safeKeys;
        if (compromisedDefaultsFound) {
          console.warn("[SECURITY] Removed exposed sample sub-admin passwords from persistent state.");
          await saveStoreData(merged);
          return merged;
        }
        memoryCache = merged;
        cacheTime = Date.now();
        writeLocalBackup(merged);
        return merged;
      }
    } catch (err) {
      console.error("Supabase load exception:", err);
    }
  }

  if (localData) {
    const merged = { ...DEFAULT_STATE, ...localData };
    const oldKeys = Array.isArray(merged.subAdminKeys) ? merged.subAdminKeys : [];
    const safeKeys = oldKeys.filter((key: any) => !isCompromisedSampleAdminKey(key));
    merged.subAdminKeys = safeKeys;
    if (safeKeys.length !== oldKeys.length) {
      console.warn("[SECURITY] Removed exposed sample sub-admin passwords from local state.");
      await saveStoreData(merged);
      return merged;
    }
    memoryCache = merged;
    cacheTime = Date.now();
    return merged;
  }

  memoryCache = { ...DEFAULT_STATE };
  cacheTime = Date.now();
  return memoryCache;
}

// ============================================================
// Save state
// ============================================================

async function saveStoreData(data: any): Promise<void> {
  const enrichedData = {
    ...data,
    _lastUpdated: Date.now(),
  };

  // Always write local first
  try {
    writeLocalBackup(enrichedData);
  } catch (err) {
    console.error("[SAVE] Local backup failed:", err);
    throw new Error("Could not write local database backup.");
  }

  memoryCache = enrichedData;
  cacheTime = Date.now();

  if (!supabase) {
    console.warn("[SAVE] Supabase not configured — saved locally only.");
    return;
  }

  try {
    const { error } = await supabase
      .from(TABLE)
      .upsert({ id: ROW_ID, data: enrichedData, updated_at: new Date().toISOString() }, { onConflict: "id" });

    if (error) {
      console.error("[SAVE] Supabase write failed:", error.message);
      // Local already saved — do not fail the request
      return;
    }

    console.log(
      "[SAVE] Supabase confirmed. Staff count:",
      Array.isArray(enrichedData.staffList) ? enrichedData.staffList.length : "?"
    );
  } catch (err) {
    console.error("[SAVE] Supabase exception:", err);
    // Local already saved
  }
}

// ============================================================
// Admin authentication
// ============================================================

type AdminSession = {
  name: string;
  isOwner: boolean;
  permissions: string[];
  expiresAt: number;
};

const sessions = new Map<string, AdminSession>();
const SESSION_TTL_MS = 8 * 60 * 60 * 1000;
const loginAttempts = new Map<string, { count: number; resetAt: number }>();

function getSession(req: express.Request): AdminSession | null {
  const auth = req.header("authorization") || "";
  if (!auth.startsWith("Bearer ")) return null;
  const token = auth.slice(7).trim();
  if (!token) return null;

  // Only opaque, server-issued session tokens are accepted. Passwords are never bearer tokens.
  const session = sessions.get(token);
  if (!session) return null;
  if (session.expiresAt <= Date.now()) {
    sessions.delete(token);
    return null;
  }
  return session;
}

function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction): void {
  const session = getSession(req);
  if (!session) {
    res.status(401).json({ success: false, error: "Admin authentication required." });
    return;
  }
  (req as any).adminSession = session;
  next();
}

const FIELD_PERMISSION: Record<string, string> = {
  staffList: "staff",
  leaderboard: "supporters",
  items: "products",
  categories: "products",
  couponsList: "discounts",
  saleConfig: "discounts",
  tickets: "tickets",
  updatesList: "updates",
  voteLinks: "vote",
  config: "settings",
  subAdminKeys: "passwords",
  connectionGuide: "guide",
  rulesCategories: "rules",
  activityLogs: "activity_log",
};

function publicState(state: Record<string, any>): Record<string, any> {
  const { subAdminKeys, tickets, activityLogs, ...safe } = state;
  if (Array.isArray(safe.couponsList)) {
    safe.couponsList = safe.couponsList.filter((coupon: any) => coupon?.category !== "private");
  }
  if (safe.config && typeof safe.config === "object") {
    const { discordWebhookUrl, ...publicConfig } = safe.config;
    safe.config = { ...publicConfig, discordWebhookUrl: "", discordWebhookConfigured: Boolean(discordWebhookUrl) };
  }
  return safe;
}

function hasPermission(session: AdminSession, permission: string): boolean {
  return session.isOwner || session.permissions.includes("*") || session.permissions.includes(permission);
}

function cleanText(value: unknown, maxLength: number): string {
  return typeof value === "string" ? value.replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, maxLength) : "";
}

async function sendSafeDiscordAlert(state: Record<string, any>, embed: Record<string, any>, content = "", webhookOverride = ""): Promise<boolean> {
  const config = state.config || {};
  const webhookUrl = (typeof webhookOverride === "string" && webhookOverride.trim()) || (typeof config.discordWebhookUrl === "string" ? config.discordWebhookUrl.trim() : "");
  if (!config.discordWebhookEnabled || !webhookUrl || !webhookUrl.startsWith("https://discord.com/api/webhooks/")) return false;
  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: cleanText(config.discordBotName, 80) || "WonderMC Store Bot",
        avatar_url: cleanText(config.discordAvatarUrl, 500) || "https://mc-heads.net/avatar/MHF_Chest/128",
        content,
        allowed_mentions: { parse: [] },
        embeds: [{ ...embed, timestamp: new Date().toISOString() }],
      }),
    });
    if (!response.ok && response.status !== 204) console.warn("[Discord] Safe notification failed:", response.status);
    return response.ok || response.status === 204;
  } catch (error) {
    console.warn("[Discord] Safe notification network failure:", error);
    return false;
  }
}

function adminStateForSession(state: Record<string, any>, session: AdminSession): Record<string, any> {
  if (session.isOwner || session.permissions.includes("*")) {
    const ownerSafe = { ...state };
    if (ownerSafe.config && typeof ownerSafe.config === "object") ownerSafe.config = { ...ownerSafe.config, discordWebhookUrl: "" };
    return ownerSafe;
  }
  const filtered: Record<string, any> = {};
  for (const [key, permission] of Object.entries(FIELD_PERMISSION)) {
    if (key === "subAdminKeys" && !session.isOwner && !session.permissions.includes("*")) continue;
    if (hasPermission(session, permission) && Object.prototype.hasOwnProperty.call(state, key)) filtered[key] = state[key];
  }
  // Payment-only staff can configure payment fields but never receive stored Discord webhook credentials.
  if (filtered.config && typeof filtered.config === "object") {
    filtered.config = { ...filtered.config, discordWebhookUrl: "" };
  }
  return filtered;
}

// ============================================================
// Routes
// ============================================================

app.get("/api/health", (_req, res) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({ ok: true, service: "wondermc", database: supabase ? "supabase" : "local" });
});

app.post("/api/admin/login", async (req, res) => {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  const attempt = loginAttempts.get(ip);

  if (attempt && attempt.resetAt > now && attempt.count >= 8) {
    res.status(429).json({ error: "Too many login attempts. Wait a few minutes and try again." });
    return;
  }
  if (!attempt || attempt.resetAt <= now) {
    loginAttempts.set(ip, { count: 1, resetAt: now + 10 * 60 * 1000 });
  } else {
    attempt.count += 1;
  }

  const password = typeof req.body?.password === "string" ? req.body.password : "";
  if (!password || password.length > 256) {
    res.status(400).json({ error: "Enter a valid admin password." });
    return;
  }

  try {
    const state = await loadStoreData();
    const ownerPassword = process.env.OWNER_PASSWORD || "";
    let session: AdminSession | null = null;
    let responseKeys: any[] | undefined;

    const passwordBuffer = Buffer.from(password);
    const ownerBuffer = Buffer.from(ownerPassword);
    const ownerMatches =
      Boolean(ownerPassword) &&
      passwordBuffer.length === ownerBuffer.length &&
      crypto.timingSafeEqual(passwordBuffer, ownerBuffer);

    if (ownerMatches) {
      session = {
        name: "Main Server Owner",
        isOwner: true,
        permissions: ["*"],
        expiresAt: now + SESSION_TTL_MS,
      };
      responseKeys = Array.isArray(state.subAdminKeys) ? state.subAdminKeys : [];
      loginAttempts.delete(ip);
    } else {
      const keys = Array.isArray(state.subAdminKeys) ? state.subAdminKeys : [];
      const matched = keys.find((key: any) => typeof key?.password === "string" && key.password === password);
      if (matched) {
        if (matched.isOwner === true || (Array.isArray(matched.permissions) && matched.permissions.includes("*"))) {
          session = {
            name: String(matched.name || "Owner").slice(0, 80),
            isOwner: true,
            permissions: ["*"],
            expiresAt: now + SESSION_TTL_MS,
          };
          responseKeys = keys;
          loginAttempts.delete(ip);
        } else if (Array.isArray(matched.permissions) && matched.permissions.length > 0) {
          session = {
            name: String(matched.name || "Sub-Admin").slice(0, 80),
            isOwner: false,
            permissions: matched.permissions.filter((p: any) => typeof p === "string"),
            expiresAt: now + SESSION_TTL_MS,
          };
          loginAttempts.delete(ip);
        }
      }
    }

    if (!session) {
      res.status(401).json({ error: "Invalid admin password." });
      return;
    }

    const token = crypto.randomBytes(32).toString("hex");
    sessions.set(token, session);
    res.setHeader("Cache-Control", "no-store");
    res.json({
      token,
      name: session.name,
      isOwner: session.isOwner,
      permissions: session.permissions,
      ...(responseKeys ? { subAdminKeys: responseKeys } : {}),
      expiresIn: SESSION_TTL_MS,
    });
  } catch (err) {
    console.error("Admin login failed:", err);
    res.status(503).json({ error: "Authentication service temporarily unavailable." });
  }
});

app.post("/api/admin/logout", requireAdmin, (req, res) => {
  const auth = req.header("authorization") || "";
  sessions.delete(auth.slice(7).trim());
  res.setHeader("Cache-Control", "no-store");
  res.json({ success: true });
});

app.get("/api/state", async (_req, res) => {
  try {
    const state = await loadStoreData();
    res.setHeader("Cache-Control", "no-store");
    res.json(publicState(state));
  } catch (err) {
    console.error("State read failed:", err);
    res.status(503).json({ error: "Database temporarily unavailable." });
  }
});

app.get("/api/admin/state", requireAdmin, async (req, res) => {
  try {
    const state = await loadStoreData();
    const session = (req as any).adminSession as AdminSession;
    res.setHeader("Cache-Control", "no-store");
    res.json(adminStateForSession(state, session));
  } catch (err) {
    console.error("Admin state read failed:", err);
    res.status(503).json({ error: "Database temporarily unavailable." });
  }
});

app.get("/api/admin/tickets", requireAdmin, async (req, res) => {
  const session = (req as any).adminSession as AdminSession;
  if (!hasPermission(session, "tickets")) {
    res.status(403).json({ error: "You do not have permission to view support/payment records." });
    return;
  }
  try {
    const state = await loadStoreData();
    res.setHeader("Cache-Control", "no-store, private, max-age=0");
    res.setHeader("Pragma", "no-cache");
    res.json({ tickets: Array.isArray(state.tickets) ? state.tickets : [] });
  } catch (err) {
    console.error("Admin tickets read failed:", err);
    res.status(503).json({ error: "Could not load tickets." });
  }
});

// Load saved staff passwords for the owner panel
app.get("/api/admin/passwords", requireAdmin, async (req, res) => {
  const session = (req as any).adminSession as AdminSession;
  if (!session.isOwner && !session.permissions.includes("*")) {
    res.status(403).json({ error: "Only the owner can view staff passwords." });
    return;
  }
  try {
    const state = await loadStoreData();
    res.setHeader("Cache-Control", "no-store");
    res.json({ subAdminKeys: Array.isArray(state.subAdminKeys) ? state.subAdminKeys : [] });
  } catch (err) {
    console.error("Passwords read failed:", err);
    res.status(503).json({ error: "Could not load passwords" });
  }
});

app.post("/api/state", requireAdmin, async (req, res) => {
  const session = (req as any).adminSession as AdminSession;
  const incoming = req.body;

  res.setHeader("Cache-Control", "no-store");

  if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) {
    res.status(400).json({ success: false, error: "Request body must be a JSON object." });
    return;
  }

  try {
    const allowed: Record<string, any> = {};

    for (const [key, value] of Object.entries(incoming)) {
      if (key === "_lastUpdated") continue;

      if (key === "subAdminKeys" && !session.isOwner && !session.permissions.includes("*")) continue;
      const requiredPermission = FIELD_PERMISSION[key];
      const hasPermission =
        !!requiredPermission &&
        (session.permissions.includes(requiredPermission) ||
          (key === "config" && (session.permissions.includes("payment") || session.permissions.includes("settings"))));

      const permitted = session.isOwner || session.permissions.includes("*") || hasPermission;
      if (!permitted) continue;

      if (
        key === "config" &&
        !session.isOwner &&
        !session.permissions.includes("*") &&
        session.permissions.includes("payment") &&
        !session.permissions.includes("settings")
      ) {
        const current = await loadStoreData();
        allowed.config = {
          ...(current.config || {}),
          upiId: (value as any)?.upiId,
          upiPayeeName: (value as any)?.upiPayeeName,
          customQrUrl: (value as any)?.customQrUrl,
          qrMode: (value as any)?.qrMode,
        };
      } else {
        allowed[key] = value;
      }
    }

    if (Object.keys(allowed).length === 0) {
      res.status(403).json({
        success: false,
        error: "Your admin role is not allowed to change these fields.",
      });
      return;
    }

    const current = await loadStoreData();
    // The webhook URL is server-side secret material. A blank value from the browser must not erase it.
    if (allowed.config && !allowed.config.discordWebhookUrl && current.config?.discordWebhookUrl) {
      allowed.config = { ...allowed.config, discordWebhookUrl: current.config.discordWebhookUrl };
    }
    const merged = { ...current, ...allowed };

    await saveStoreData(merged);

    res.status(200).json({
      success: true,
      saved: true,
    });
  } catch (err) {
    console.error("State save failed:", err);
    // Still try to return success if local backup exists
    res.status(200).json({
      success: true,
      saved: true,
      warning: "Saved locally",
    });
  }
});

const ticketAttempts = new Map<string, { count: number; resetAt: number }>();

app.post("/api/tickets", async (req, res) => {
  const ip = req.ip || req.socket.remoteAddress || "unknown";
  const now = Date.now();
  const attempt = ticketAttempts.get(ip);
  if (attempt && attempt.resetAt > now && attempt.count >= 5) {
    res.status(429).json({ error: "Too many ticket submissions. Please wait a few minutes." });
    return;
  }
  if (!attempt || attempt.resetAt <= now) ticketAttempts.set(ip, { count: 1, resetAt: now + 10 * 60 * 1000 });
  else attempt.count += 1;

  const body = req.body || {};
  const ign = cleanText(body.ign, 32);
  const message = cleanText(body.message, 5000);
  const category = cleanText(body.category, 80);
  const contact = cleanText(body.contact, 120);
  const subject = cleanText(body.subject, 160) || `${category} inquiry`;
  const screenshotUrl = typeof body.screenshotUrl === "string" ? body.screenshotUrl.trim() : "";

  if (!ign || !message || !category) {
    res.status(400).json({ error: "Player name, category, and message are required." });
    return;
  }
  if (screenshotUrl && (!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/i.test(screenshotUrl) || screenshotUrl.length > 11_300_000)) {
    res.status(400).json({ error: "Screenshot must be an uploaded PNG, JPG, or WEBP image under 8MB." });
    return;
  }
  if (/[\r\n]/.test(ign)) {
    res.status(400).json({ error: "Enter a valid Minecraft username." });
    return;
  }

  try {
    const state = await loadStoreData();
    const randomNum = crypto.randomInt(1000, 10000);
    const ticket = {
      id: `ticket-${Date.now()}-${crypto.randomBytes(4).toString("hex")}`,
      ticketNumber: `TKT-${randomNum}`,
      ign,
      contact,
      category,
      subject,
      message,
      screenshotUrl: screenshotUrl || undefined,
      status: "open",
      priority: body.priority === "high" || body.priority === "low" ? body.priority : "medium",
      createdAt: new Date().toISOString(),
      adminNote: "",
    };
    const tickets = Array.isArray(state.tickets) ? state.tickets : [];
    await saveStoreData({ ...state, tickets: [ticket, ...tickets].slice(0, 1000) });

    // Discord receives only a minimal alert. Payment proof, UTR, contacts and support messages remain private.
    const isPayment = category.toLowerCase().includes("payment");
    const notifyEnabled = isPayment ? state.config?.discordNotifyOnPayment !== false : state.config?.discordNotifyOnTicket !== false;
    if (notifyEnabled) {
      void sendSafeDiscordAlert(state, {
        title: isPayment ? "New payment submitted for manual verification" : "New support ticket received",
        description: "A new record is available in the authenticated WonderMC Admin Panel. Do not request or post payment proof in Discord.",
        color: isPayment ? 0xf59e0b : 0x3b82f6,
        fields: [
          { name: "Ticket", value: `#${ticket.ticketNumber}`, inline: true },
          { name: "Minecraft IGN", value: ign.slice(0, 100), inline: true },
          { name: "Category", value: category.slice(0, 80), inline: true },
        ],
        footer: { text: "WonderMC • Sensitive details are available only in the Admin Panel" },
      });
    }

    // Return only a receipt reference to the submitting browser, never echo back private fields or the image.
    res.status(201).json({ success: true, ticket: { id: ticket.id, ticketNumber: ticket.ticketNumber } });
  } catch (err) {
    console.error("Ticket submission failed:", err);
    res.status(503).json({ error: "Could not submit your ticket. Please try again later." });
  }
});

app.post("/api/admin/discord-test", requireAdmin, async (req, res) => {
  const session = (req as any).adminSession as AdminSession;
  if (!hasPermission(session, "settings")) {
    res.status(403).json({ error: "Only authorised settings admins can test Discord notifications." });
    return;
  }
  const state = await loadStoreData();
  const config = state.config || {};
  const requestedWebhook = cleanText(req.body?.webhookUrl, 500);
  const sent = await sendSafeDiscordAlert(state, {
    title: `${cleanText(config.brand, 60) || "WonderMC"} Discord connection test`,
    description: "Safe notification test successful. Payment proofs and private support messages are not sent to Discord.",
    color: 0x10b981,
    fields: [{ name: "Server", value: cleanText(config.serverIp, 100) || "Configured", inline: true }],
  }, "", requestedWebhook);
  if (!sent) { res.status(400).json({ error: "Discord webhook is not configured or could not be reached." }); return; }
  res.json({ success: true });
});

app.post("/api/admin/notify/approved", requireAdmin, async (req, res) => {
  const session = (req as any).adminSession as AdminSession;
  if (!hasPermission(session, "tickets")) { res.status(403).json({ error: "Not allowed." }); return; }
  const state = await loadStoreData();
  const ign = cleanText(req.body?.ign, 32);
  const ticketNumber = cleanText(req.body?.ticketNumber, 20);
  const approvedBy = cleanText(req.body?.approvedBy, 80) || session.name;
  const sent = await sendSafeDiscordAlert(state, {
    title: "Payment manually verified / order fulfilled",
    description: "An authorised staff member marked an order as verified in the Admin Panel.",
    color: 0x10b981,
    fields: [
      { name: "Minecraft IGN", value: ign || "Player", inline: true },
      { name: "Ticket", value: ticketNumber ? `#${ticketNumber}` : "N/A", inline: true },
      { name: "Verified by", value: approvedBy, inline: true },
    ],
  });
  res.json({ success: sent });
});

// ============================================================
// Start server
// ============================================================

async function startServer(): Promise<void> {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`WonderMC server listening on port ${PORT} (db: ${supabase ? "supabase" : "local"})`);
  });
}

startServer().catch((err) => {
  console.error("Could not start WonderMC:", err);
  process.exit(1);
});
